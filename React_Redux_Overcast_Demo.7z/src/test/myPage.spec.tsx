import * as React from 'react';
import {mount} from 'enzyme';
import {expect} from 'chai';
import 'mocha';
import jsdomify from 'jsdomify';
import MyPage from '../components/myPage';


describe("Test Without Exploding Environment", function(){


  let _page, div

  beforeEach(()=>{
    jsdomify.create();
    document.open()
    document.write("<html><body><p>TypeScript Page</p></body></html>")
    div = document.createElement('div')

    _page=mount(<MyPage />, { attachTo: div })
    console.log("Document " , document);
  })

  afterEach(()=>{
    _page.detach();
    document.body.removeChild(div);
    jsdomify.destroy();
  })

  it.only('MyPage should exist', function(){
    expect(_page.find(MyPage)).to.have.length(1);
  })

  it("Should Pass the Initial Render", ()=>{
    expect(true).to.equal(true);
  });
})
