import * as React from 'react';

interface Props extends React.Props<Authors>{

}

class Authors extends React.Component<Props, {}>{

  public render(){
    return(<div className="row">
      <h2>Members Page</h2>
    </div>
    )
  }
}

export default Authors;
