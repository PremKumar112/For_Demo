import * as React from 'react';

interface Props extends React.Props<JustHello>{
  name:string
}

export class JustHello extends React.Component<Props, {}>{

  public render(){
    return(<div className="container">
      <h1>Hello To Test Packages and <h1 className="justHello">{this.props.name}</h1></h1>
    </div>);
  }
}
