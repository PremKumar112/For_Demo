filename:
test.spec.tsx

import * as React from 'react';
import { mount } from 'enzyme';
import { expect } from 'chai';
import 'mocha';
import jsdomify from 'jsdomify';

import Header from '../components/common/header';


describe('Should have a Header div', function(){

  let _page, div

  beforeEach(function(){
    jsdomify.create();
    document.open();
    document.write("<html><body><p>Hello World!!</p></body></html>");
    div=document.createElement('div');
    document.body.appendChild(div);
    _page=mount(<Header name="Mark"/>, {attachTo: div});
    console.log("Document", document);
  })

  afterEach(function(){
    _page.detach();
    document.body.removeChild(div);
    jsdomify.destroy();
  })

  it('should have children', function(){
    expect(_page.children()).to.exist;
  });

  it('should have props by name Mark', function(){
    expect(_page.props().name).to.equal('Mark');
  })
})

describe('---Just checking the Hot Reload', ()=>{
  it('should just do a True', function(){
    expect(true).to.equal(true);
  })
})
