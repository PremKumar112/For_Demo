
filename:
actionTest.spec.tsx

import { expect } from 'chai';
import { mount } from 'enzyme';
import 'mocha';
import jsdomify from 'jsdomify';
import sinon from 'sinon';
import sinonStubPromise from 'sinon-stub-promise';
import * as React from 'react';
import MembersPage from '../components/members/membersPage';

describe("MemberPage Mount and Promise", function(){

  it.ignore('calls fetchData on Component Mount', ()=>{
    const fetchData=sinon.stub();
    const component= mount(<MembersPage />)
    expect(true).to.equal(true);
  })
})
