import * as React from 'react';

interface Props extends React.Props<Navig>{

}

interface State{

}
export default class Navig extends React.Component<Props,State>{

  public render(){
    return(<div className="row">
      <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
        <h1>This is Navigation</h1>
      </div>
    </div>);
  }

}
