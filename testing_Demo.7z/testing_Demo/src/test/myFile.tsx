import * as React from 'react';
import { mount } from 'enzyme';
import { expect } from 'chai';
import 'mocha';
import jsdomify from 'jsdomify';

import Header from '../components/common/header';

describe('Should have a div', function(){
  it('should have props by name Mark', function(){
    expect(true).to.equal(true);
  })
})
