import MemberEntity from './memberEntity';

var	MembersMockData : Array<MemberEntity> =
	[
		{
      id: 1457912,
      login: "brauliodiez",
      avatar_url: "http://www.gstatic.com/webp/gallery/1.jpg"
		},
    {
      id: 4374977,
      login: "Nasdan",
      avatar_url: "https://avatars.githubusercontent.com/u/4374977?v=3"
    }
	];

  export default MembersMockData;
