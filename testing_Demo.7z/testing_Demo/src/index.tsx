import * as React from 'react';
import * as ReactDOM from 'react-dom';
import NewApp from './staticTester/newApp';

ReactDOM.render(<NewApp store_one="Electronics" store_two="Clothes" />,
 document.getElementById('root'));
