import * as React from 'react';
import { connect } from 'react-redux';
import { Sparklines, SparklinesLine, SparklinesReferenceLine } from 'react-sparklines';

interface Props extends React.Props<CloudRender>{
  employee?:Array<any>
}

interface State{

}

class CloudRender extends React.Component<Props, State>{

    constructor(props){
    super(props);
    }



    displayWeather(cityData, index){
      const temp = cityData.list.map(weath => weath.main.temp);
      const press = cityData.list.map(weath=>weath.main.pressure);
      const humidity = cityData.list.map(weath=>weath.main.humidity);

      var total=0;
      for(var i in temp) { total += temp[i]; }
      var t:number= Math.round(total/360);

      var totalp=0;
      for(var i in press) { totalp += press[i]; }
      var p:number= Math.round(totalp/360);

      var totalh=0;
      for(var i in humidity) { totalh += humidity[i]; }
      var h:number= Math.round(totalh/36);

    return(
      <tr key={index}>
        <td><h2>{cityData.city.name}</h2></td>
        <td>
            <Sparklines data={temp} style={{background: "#00bdcc"}} margin={10} height={40}>
            <SparklinesLine style={{ stroke: "red", fill: "8fc638" }} />
            <SparklinesReferenceLine
              style={{ stroke: 'white', strokeOpacity: .75, strokeDasharray: '2, 2' }} />
            </Sparklines>
            <h6>Average Temperature: {t} &#x2103;</h6>
        </td>
        <td>
          <Sparklines data={press} style={{background: "#f4425c"}} margin={10} height={40}>
          <SparklinesLine style={{ stroke: "blue", fill: "8fc638" }} />
          <SparklinesReferenceLine
          style={{ stroke: 'white', strokeOpacity: .75, strokeDasharray: '2, 2' }} />
          </Sparklines>
          <h6>Average Pressure: {p}</h6>
        </td>
        <td>
          <Sparklines data={humidity} style={{background: "#00bdcc"}} margin={10} height={40}>
          <SparklinesLine style={{ stroke: "black", fill: "8fc638" }} />
          <SparklinesReferenceLine
          style={{ stroke: 'white', strokeOpacity: .75, strokeDasharray: '2, 2' }} />
          </Sparklines>
          <h6>Average Humidity: {h}</h6>
        </td>
      </tr>)
    }

    public render(){

      var listWeather:any;
        if(this.props.employee){
        listWeather=this.props.employee.map(this.displayWeather);
      }

      return(
      <div className="row">
      <table className="table table-bordered bg-warning">
        <thead>
          <tr>
          <th><h4>City</h4></th>
          <th><h4>Temperature</h4></th>
          <th><h4>Pressure</h4></th>
          <th><h4>Humidity</h4></th>
          <th><h4>Actions</h4></th>
          </tr>
        </thead>
        <tbody>
          {listWeather}
        </tbody>
      </table>
      </div>
      )
    }
}

const mapStatetoProps = (state) =>{
  console.log(state);
  return {
    employee: (state.employees!=null)?state.employees.weather:[]
  }
}

export default connect(mapStatetoProps, null)(CloudRender);
