import * as React from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import fetchWeather from '../actions';
import CloudRender from './cloudRender';

interface Props extends React.Props<MyPage> {
  fetchWeather? : (city:string) => void;
  name?:string;
}

interface State {
  mySearch:string;
}

class MyPage extends React.Component<Props, State>{
    constructor(props){
    super(props);
    this.state = {mySearch: ''};
    this.onInputChange = this.onInputChange.bind(this);
    this.onFormSubmit = this.onFormSubmit.bind(this);
}

onFormSubmit=(event)=>{
  event.preventDefault();
  let city:string = this.state.mySearch;

  this.props.fetchWeather(city);
  this.setState({ mySearch: '' });
}

onInputChange =(event)=>{
  this.setState({ mySearch: event.target.value });
}

  public render(){

      return(<div className="container">
      <div className="row">
      <h1>OverCast</h1>
      <hr />
      <div className="col-md-1 col-lg-1"></div>
      <div className="col-xs-12 col-sm-12 col-md-10 col-lg-10">
      <form onSubmit ={this.onFormSubmit} className="input-group">
        <input
        placeholder="Get Week Forecast of your City"
        className="form-control"
        value={this.state.mySearch}
        onChange={this.onInputChange}/>
        <span className="input-group-btn">
          <button type="submit" className="btn btn-secondary">Submit</button>
        </span>
      </form>
      <hr />
      </div>
      <div className="col-md-1 col-lg-1"></div>
      </div>
      <CloudRender />
      </div>);
  }
}

const mapDispatchToProps = (dispatch)=>{
  return bindActionCreators ({fetchWeather}, dispatch);
}

export default connect(null, mapDispatchToProps)(MyPage);
