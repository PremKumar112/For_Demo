import * as React from 'react';
import Header from './common/header';
import About from './about/aboutPage';

interface Props extends React.Props<App>{

}

interface State{

}

class App extends React.Component<Props, State>{

  public render(){
    return(<div className="container">
      <Header />
      {this.props.children}
    </div>

    )
  }
}

export default App;
