db.employeeDetails.insert({_id:1, empId:47873, empName:"Raghavendra", emailid:"raghavendra.nk7@gmail.com", mobileNo:"8970361988", address:"Davangere"});
WriteResult({ "nInserted" : 1 })