import * as React from 'react';
import MemberEntity from '../../api/memberEntity';
import memberAPI from '../../api/memberAPI';
import MemberRow from './memberRow';

interface Props extends React.Props<MembersPage> {
}

// We define members as a state (the compoment holding this will be a container
// component)
interface State {
  members : Array<MemberEntity>
}

// Nice tsx guide: https://github.com/Microsoft/TypeScript/wiki/JSX
export default class MembersPage extends React.Component<Props, State> {

  constructor(props : Props){
        super(props);
        // set initial state
        this.state = {members: []};
  }

   // Standard react lifecycle function:
   // https://facebook.github.io/react/docs/component-specs.html

   public componentWillMount() {
     // this.state.members = memberAPI.getAllMembers();
     var promise = memberAPI.getAllMembersAsync();
     var emps: Array<MemberEntity>=[];
     promise.then((response)=>{
           console.log(response.data);
           emps=response.data.map((each)=>{
           var member: MemberEntity= new MemberEntity();
           member.id=each.id;
           member.login=each.login;
           member.avatar_url=each.avatar_url;
           console.log(member);
           return member;
         });

         this.setState({members: emps})
     })

   }

   public render() {
      var CreateMemberRow = function(member : MemberEntity) {
        return (
            <tr key={member.id}>
              <td>
                <img src={member.avatar_url} className="avatar"/>
              </td>
              <td>
                <span>{member.id}</span>
              </td>
              <td>
                <span>{member.login}</span>
              </td>
            </tr>
        )
      }

       return (
        <div className="row memberpage">
          <h2> Members Page</h2>
          <table className="table table-bordered avatartab">
            <thead>
              <tr>
                <th className="col-md-2">
                  Avatar
                </th>
                <th className="col-md-2">
                  Id
                </th>
                <th className="col-md-2">
                  Name
                </th>
              </tr>
            </thead>
            <tbody>
              {this.state.members.map((member: MemberEntity)=>
                  <MemberRow key={member.id} member={member} />
                )
              }
            </tbody>
          </table>
        </div>
       );
  }
}
