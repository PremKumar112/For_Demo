import * as React from 'react';
import { mount, shallow } from 'enzyme';
import { expect } from 'chai';
import sinon from 'sinon';
import 'mocha';
import jsdomify from 'jsdomify';
import NewApp from '../staticTester/newApp';
import Header from '../staticTester/compens/header';
import Navig from '../staticTester/compens/navig';


describe('Should have a Header div', function(){

  let _page, _pageHeader, div

  beforeEach(function(){
    jsdomify.create();
    document.open();
    document.write("<html><body><p>Hello World!!</p></body></html>");
    div=document.createElement('div');
    document.body.appendChild(div);
    _page=mount(<NewApp store_one="Electronics" store_two="Clothes" />, {attachTo: div});
    _page.setState({location:'Atlanta', income:'High'});
    console.log("Document", document);
  })

  afterEach(function(){
    _page.detach();
    document.body.removeChild(div);
    jsdomify.destroy();
  })

  it('should have 4 children', function(){
    expect(_page.children().length).to.equal(5);
  });

  it('should have props by name Electronics', function(){
    expect(_page.props().store_one).to.equal('Electronics');
  })
  it("App should contain a footer component", function(){
    expect(_page.find(Navig)).to.have.length(1);
  })
  it("should have props for storeone and storetwo", function(){
    expect(_page.find('img')).to.have.length(1);
  })

  it("should have state set for location", function(){
    expect(_page.state().location).to.equal('Atlanta');
  })

  it("should have state set for income", function(){
    expect(_page.state().income).to.equal('High');
  })

  it("Header should have a passed props from parent", function(){
    expect(_pageHeader.props().store_one).to.equal('Electronics');
  })

})

describe('---Just checking the Hot Reload', ()=>{
  it('should just do a True', function(){
    expect(true).to.equal(true);
  })
})
