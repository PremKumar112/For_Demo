import * as React from 'react';
import {Link} from 'react-router';

interface Props extends React.Props<About> {
}

// Nice tsx guide: https://github.com/Microsoft/TypeScript/wiki/JSX
export default class About extends React.Component<Props, {}> {
   public render() {
       return (
          <div className="row aboutP">
            <h2 className="jumbotron"> About Page</h2>
            <Link to="/members">Members</Link>
          </div>
       );
  }
}
