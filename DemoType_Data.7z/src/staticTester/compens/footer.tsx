import * as React from 'react';

interface Props extends React.Props<Footer>{

}
interface State{

}

export default class Footer extends React.Component<Props, State>{

  public render(){
    return(<footer>
      <div className="col-xs-12 col-sm-12 col-md-3 col-lg-3">

          <p>Copyright @Aricent.com</p>
        
      </div>
    </footer>);
  }

}
