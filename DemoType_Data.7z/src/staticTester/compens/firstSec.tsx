import * as React from 'react';

interface Props extends React.Props<FirstSec>{

}
interface State{

}

export default class FirstSec extends React.Component<Props, State>{

  public render(){
    return(<div className="row">
    <div className="col-xs-12 col-sm-12 col-md-8 col-lg-8">
      <h1>This is the middle Section</h1>
    </div>
    </div>)
  }

}
