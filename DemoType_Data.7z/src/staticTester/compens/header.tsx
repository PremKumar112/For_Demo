import * as React from 'react';

interface Props extends React.Props<Header>{
store_one:string;
store_two:string;
}

interface State{
  name:string;
}

export default class Header extends React.Component<Props, State>{

  constructor(props){
    super(props);

    this.state={
      name:''
    }
  }

  public componentWillMount(){
    this.setState({name: this.props.store_one})
  }


  public render(){
    return(<div className="row">
    <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
        <nav className="navbar navbar-default">
          <div className="container-fluid">
            <ul className="nav navbar-nav">
              <li ><a href="#">{this.state.name}</a></li>
              <li><a href="#">Clothes</a></li>
              <li><a href="#">Accessories</a></li>
              <li><a href="#">Help</a></li>
            </ul>
          </div>
        </nav>
      </div>
    </div>);
  }
}
