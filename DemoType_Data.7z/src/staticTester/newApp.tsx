import * as React from 'react';
import Header from './compens/header';
import Footer from './compens/footer';
import FirstSec from './compens/firstSec';
import Navig from './compens/navig';

interface Props extends React.Props<NewApp>{
  store_one:string;
  store_two:string;
}

interface State{
  location?:string;
  income?:string;
}

export default class NewApp extends React.Component<Props, State>{

  constructor(props){
    super(props);
    this.state={location:'', income:''}
  }
  public componentWillMount(){
    console.log("Component Has Mounted");
  }

  public render(){
    return(<div className="container">
      <img src="#" alt="logo" />
      <Header {...this.props}/>
      <FirstSec />
      <Navig />
      <Footer/>
    </div>);
  }

}
