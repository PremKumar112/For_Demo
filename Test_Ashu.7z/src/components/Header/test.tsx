import * as React from 'react';
import { mount } from 'enzyme';
import {expect} from 'chai';
import 'mocha';
import { sinon } from 'sinon';
import jsdomify from 'jsdomify';
import {Header} from './header';
import {App} from '../../containers/App'


describe('Should have Header div', () =>{
    let _page, div

    beforeEach(() => {
        jsdomify.create();
        document.open()
        document.write("<html><body><p>Hello World!</p></body></html>")
        div = document.createElement('div')
        document.body.appendChild(div)
        _page = mount(
                 <Header name="Ashu" />
            ,{ attachTo: div })
        console.log("Document " , document);
   })

    afterEach(() => {
        _page.detach()
        document.body.removeChild(div)
        jsdomify.destroy();
    })


  it('Header Prop should exist', function(){
    expect(_page.props().name).to.equal("Ashu");
  });


  it.only('Header should have 3 children', function(){
    expect(_page.children().length).to.equal(3);
  });

  it('App should contain a Header Component', function(){
    expect(_page.find(Header)).to.have.length(1);
  });

  it('should call Lifecycle componentWillMount on mounting', ()=>{
    const componentWMount = sinon.spy(_page.prototype, 'componentWillMount');
    expect(_page.prototype.componentWillMount.calledOnce).to.equal(true);
  });



});
