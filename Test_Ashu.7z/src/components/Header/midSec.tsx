import * as React from 'react';

interface Props extends React.Props<MidSec>{

}

interface State{

}

export default class MidSec extends React.Component<State, Props>{

  constructor(props){
    super(props);
  }
  public render(){

    return(<div>
    <h1>I am a Child</h1>
    </div>)

  }

}
