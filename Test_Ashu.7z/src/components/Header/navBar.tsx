import * as React from 'react';

interface Props extends React.Props<NavBars>{
}

interface State{
}

class NavBars extends React.Component<Props, State>{

  constructor(props){
    super(props);
  }

  public render(){
    return(<div><h2>I am a NavBar Child</h2></div>)
  }
}

export default NavBars;
