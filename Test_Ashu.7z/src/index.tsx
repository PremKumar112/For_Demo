import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { Header } from './components/Header/header.tsx';

ReactDOM.render(<Header />, document.getElementById('root'));
