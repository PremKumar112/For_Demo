import * as React from 'react'

interface AccountProps {
}

interface AccountState {
}

export class Account extends React.Component<AccountProps, AccountState> {

    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div>
            </div>
        )
    }
}
