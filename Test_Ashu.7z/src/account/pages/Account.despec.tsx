'use strict'

import * as React from 'react'
import {Account} from './Account'
import { mount } from 'enzyme'
import { expect, should } from 'chai'
import 'mocha';
import jsdomify from 'jsdomify';

describe('Account', () => {
    describe('pages', () => {
        describe('Account page', () => {
            let _wrapper, div;

            beforeEach(() => {
                jsdomify.create();
                
                document.open()
                document.write("<html><body><p>Hello World!</p></body></html>")
                div = document.createElement('div')
                document.body.appendChild(div)
                
                _wrapper = mount(<Account />
                            ,{ attachTo: div })
            })

            afterEach(() => {
                _wrapper.detach()
                document.body.removeChild(div)
                jsdomify.destroy();
            })

            it('should contain an empty div', () => {
                expect(_wrapper.children()).to.exist;
                //_wrapper.find('div').first().should.null
            })
        })
    })
})