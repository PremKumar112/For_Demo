var webpackConfig = require('./webpack.config');

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['mocha', 'chai', 'sinon', 'sinon-as-promised'],
    plugins: ['karma-mocha', 'karma-chai', 'karma-sinon', 'karma-sinon-as-promised'],
    files: [
      './test_config/index.js'
    ],
    exclude: [
    ],
    preprocessors: {
      './test_config/index.js': ['webpack', 'sourcemap']
    },
    webpack: {
      devtool: 'inline-source-map',
      module: {
          loaders: [
              {
                  test: /\.(ts|tsx)$/,
                  exclude: /node_modules/,
                  loader: 'ts-loader'
            },
            {
                test: /\.json$/,
                loader: 'json-loader'
            }
          ]
      },
      resolve: {
          extensions: ['*', '.js', '.ts', '.tsx', '.json']
      },
      externals: {
        'react/addons': true,
        'react/lib/ExecutionEnvironment': true,
        'react/lib/ReactContext': 'window',
      }
    },
    webpackMiddleware: {
        noInfo: true
    },
    reporters: ['progress', 'html'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['Chrome'],
    singleRun: false,
    concurrency: Infinity,
    htmlReporter: {
      outputDir: 'karma_html',
      templatePath: null,
      focusOnFailures: true,
      namedFiles: false,
      pageTitle: null,
      urlFriendlyName: false,
      reportName: 'report-summary-filename',
      preserveDescribeNesting: false,
      foldAll: false,
    }
  })
}
