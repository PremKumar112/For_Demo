Steps to Create your Own Boilerplate:
/*************************************/
Step 1: npm init
====>
Provide name, version & description etc...
====>
/**** React Redux TypeScript SASS Mocha Chai Enzyme Sinon Sinon-as-promised Bootstrap axios lodash Webpack and loaders ****/
Step 2: To install devDependencies:
====>
For Development:
npm install --save-dev webpack webpack-dev-server sass-loader node-sass file-loader url-loader style-loader css-loader ts-loader tsd typescript extract-text-webpack-plugin html-webpack-plugin
For Testing:
npm install --save-dev mocha @types/mocha chai @types/chai enzyme @types/enzyme sinon @types/sinon sinon-as-promised @types/sinon-as-promised jsdom @types/jsdom react-addons-test-utils @types/react-addons-test-utils
====>
Step 3:
Copy and place WebpackConfig file, tsd and tsconfig.json
