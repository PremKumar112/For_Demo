import * as React from 'react';
import * as ReactDOM from 'react-dom';
import Apps from './components/Apps';

ReactDOM.render(<Apps />, document.getElementById('app'));

/* name="Raghu" location="Atlanta" */
