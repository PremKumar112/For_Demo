import * as React from 'react';
import axios from 'axios';
import { AxiosPromise } from 'axios';

var listVal;

interface IBoxProps{
  name?: string,
  location?: string,
  age?:number,
  fetchData?:()=>AxiosPromise,
}

interface State{
  values?:Array<any>
}

export const time="Apeksha";
export const fetchDt=()=>{
  return axios.get(`https://jsonplaceholder.typicode.com/comments`);
}

export default class Apps extends React.Component<IBoxProps, State>{

  static defaultProps: IBoxProps = {
    name: `${time}`,
    location: "Sharjah",
    age: 30,
    fetchData: fetchDt
  }

  constructor(props){
    super(props);
    this.state={values:[]};
  }

  public componentWillMount(){
    const request= this.props.fetchData();
    console.log(request);
    request.then((response)=>{
      this.setState({values: response.data});
    }).catch((error)=>{
      console.log(error);
    });
  }

  public shouldComponentUpdate(nextProps, nextState){
      if(this.state.values!=nextState.values){
        return true;
      };
      return false;
  }

  showData(item){
    return(<tr key={item.id}>
        <td>{item.id}</td>
        <td>{item.name}</td>
        <td>{item.email}</td>
      </tr>)
  }

  public render(){
    console.log(this.state.values);
    if(this.state.values){
      listVal=this.state.values.map(this.showData);
    }

  return(<div>
    <h1>My name is {this.props.name} and I live in {this.props.location}</h1>
    <table className="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        {listVal}
      </tbody>
    </table>
  </div>)
  }



}



/*
Apps.defaultProps =
{
  name: "Ashish",
  location: "Sharjah",
  age: 30,
} */
