require('sinon-as-promised');
import * as React from 'react';
import { shallow, mount } from 'enzyme';
import { expect } from 'chai';
import * as sinon from 'sinon';

import Apps from '../components/Apps';

describe("Test Without Exploding", ()=>{

  it("Just Checking The Setup", ()=>{
    expect(true).to.equal(true);
  })

  it("Should have an Apps component to render", ()=>{
    const wrapper = shallow(<Apps />);
    expect(wrapper).to.exist;
  })

  it("Should call Component will mount LFcycle", ()=>{
    const spys = sinon.spy(Apps.prototype, 'componentWillMount');
    const wrapper = mount(<Apps />);
    expect(spys.calledOnce).to.equal(true);
  })

  it("calls fetchData on componentMount", ()=>{
    const fetchData= sinon.stub().resolves();
    const component = mount(<Apps fetchData={fetchData}/>);
    expect(fetchData.callCount).to.equal(1);
  })

  it("sets Component State to Set Data", ()=>{

  })

  it("calls the Rest API", ()=>{

  })

})
